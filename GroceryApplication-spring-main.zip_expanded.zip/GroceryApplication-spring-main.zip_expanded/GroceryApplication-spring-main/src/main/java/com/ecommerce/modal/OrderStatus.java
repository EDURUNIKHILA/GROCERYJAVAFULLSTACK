package com.ecommerce.modal;

public enum OrderStatus {
	PAID
}
